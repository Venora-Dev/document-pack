# 🚀 Laravel API Guide | راهنمای API لاراول | Руководство по Laravel API

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [RESTful API Basics](#restful-api-basics)
4. [Authentication](#authentication)
5. [Controllers](#controllers)
6. [Resources](#resources)
7. [Routes](#routes)
8. [Testing](#testing)

## Introduction
Laravel provides a robust framework for building RESTful APIs with features like API resources, authentication, rate limiting, and comprehensive testing tools.

## Installation
```bash
# Create new Laravel project
composer create-project laravel/laravel example-api

# Install Passport for API authentication
composer require laravel/passport

# Run migrations
php artisan migrate

# Install Passport
php artisan passport:install
```

## RESTful API Example
### Controller
```php
namespace App\Http\Controllers\API;

use App\Models\Product;
use App\Http\Resources\ProductResource;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return ProductResource::collection(Product::paginate(10));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'price' => 'required|numeric',
        ]);

        $product = Product::create($validated);
        return new ProductResource($product);
    }
}
```

### API Resource
```php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'price' => $this->price,
            'created_at' => $this->created_at->toISOString(),
        ];
    }
}
```

### Routes
```php
// routes/api.php
Route::middleware('auth:api')->group(function () {
    Route::apiResource('products', ProductController::class);
});
```

## Best Practices
1. Use API Resources for Response Transformation
2. Implement Proper Authentication
3. Version Your APIs
4. Use Request Validation
5. Implement Rate Limiting
6. Write Comprehensive Tests

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [مبانی RESTful API](#مبانی-restful-api)
4. [احراز هویت](#احراز-هویت)
5. [کنترلرها](#کنترلرها)
6. [منابع](#منابع)
7. [مسیرها](#مسیرها)
8. [تست](#تست)

## مقدمه
لاراول یک فریم‌ورک قدرتمند برای ساخت APIهای RESTful با ویژگی‌هایی مانند منابع API، احراز هویت، محدودیت نرخ و ابزارهای جامع تست ارائه می‌دهد.

## نصب
```bash
# ایجاد پروژه جدید لاراول
composer create-project laravel/laravel example-api

# نصب Passport برای احراز هویت API
composer require laravel/passport

# اجرای مهاجرت‌ها
php artisan migrate

# نصب Passport
php artisan passport:install
```

## مثال RESTful API
### کنترلر
```php
namespace App\Http\Controllers\API;

use App\Models\Product;
use App\Http\Resources\ProductResource;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return ProductResource::collection(Product::paginate(10));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'price' => 'required|numeric',
        ]);

        $product = Product::create($validated);
        return new ProductResource($product);
    }
}
```

## بهترین شیوه‌ها
۱. استفاده از منابع API برای تبدیل پاسخ
۲. پیاده‌سازی احراز هویت مناسب
۳. نسخه‌بندی APIها
۴. استفاده از اعتبارسنجی درخواست
۵. پیاده‌سازی محدودیت نرخ
۶. نوشتن تست‌های جامع

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Основы RESTful API](#основы-restful-api)
4. [Аутентификация](#аутентификация)
5. [Контроллеры](#контроллеры)
6. [Ресурсы](#ресурсы)
7. [Маршруты](#маршруты)
8. [Тестирование](#тестирование)

## Введение
Laravel предоставляет надежный фреймворк для создания RESTful API с такими функциями, как API-ресурсы, аутентификация, ограничение скорости и комплексные инструменты тестирования.

## Установка
```bash
# Создание нового проекта Laravel
composer create-project laravel/laravel example-api

# Установка Passport для аутентификации API
composer require laravel/passport

# Запуск миграций
php artisan migrate

# Установка Passport
php artisan passport:install
```

## Пример RESTful API
### Контроллер
```php
namespace App\Http\Controllers\API;

use App\Models\Product;
use App\Http\Resources\ProductResource;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return ProductResource::collection(Product::paginate(10));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:255',
            'price' => 'required|numeric',
        ]);

        $product = Product::create($validated);
        return new ProductResource($product);
    }
}
```

## Лучшие практики
1. Использование API-ресурсов для преобразования ответов
2. Внедрение правильной аутентификации
3. Версионирование API
4. Использование валидации запросов
5. Внедрение ограничения скорости
6. Написание комплексных тестов
