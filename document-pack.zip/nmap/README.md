# 🔍 Nmap Guide | راهنمای ان‌مپ | Руководство по Nmap

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Basic Scanning](#basic-scanning)
4. [Port Scanning](#port-scanning)
5. [Host Discovery](#host-discovery)
6. [Service Detection](#service-detection)
7. [OS Detection](#os-detection)
8. [Scripts and NSE](#scripts-and-nse)
9. [Output Formats](#output-formats)
10. [Best Practices](#best-practices)

## Installation
```bash
# Install Nmap
sudo apt update
sudo apt install nmap

# Verify installation
nmap --version
```

## Basic Scanning Examples
```bash
# Basic scan of a single host
nmap example.com

# Scan specific ports
nmap -p 80,443 example.com

# Scan a subnet
nmap 192.168.1.0/24

# Aggressive scan with OS and version detection
nmap -A example.com

# Stealth scan using SYN packets
nmap -sS example.com
```

## NSE Script Example
```bash
# HTTP title script
nmap --script http-title example.com

# Vulnerability scanning
nmap --script vuln example.com

# SSL/TLS scanning
nmap --script ssl-enum-ciphers -p 443 example.com
```

## Output Example
```bash
# Save output in all formats
nmap -oA scan_results example.com

# XML output
nmap -oX scan.xml example.com

# Grep-friendly output
nmap -oG scan.txt example.com
```

## Best Practices
1. Always get proper authorization
2. Use appropriate scan timing
3. Avoid disrupting services
4. Keep Nmap updated
5. Document scan results

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [اسکن پایه](#اسکن-پایه)
4. [اسکن پورت](#اسکن-پورت)
5. [کشف میزبان](#کشف-میزبان)
6. [تشخیص سرویس](#تشخیص-سرویس)
7. [تشخیص سیستم‌عامل](#تشخیص-سیستم‌عامل)
8. [اسکریپت‌ها و NSE](#اسکریپت‌ها-و-nse)
9. [فرمت‌های خروجی](#فرمت‌های-خروجی)
10. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)

## نصب
```bash
# نصب ان‌مپ
sudo apt update
sudo apt install nmap

# تأیید نصب
nmap --version
```

## مثال‌های اسکن پایه
```bash
# اسکن پایه یک میزبان
nmap example.com

# اسکن پورت‌های خاص
nmap -p 80,443 example.com

# اسکن یک زیرشبکه
nmap 192.168.1.0/24
```

## بهترین شیوه‌ها
۱. همیشه مجوز مناسب دریافت کنید
۲. از زمان‌بندی مناسب اسکن استفاده کنید
۳. از اختلال در سرویس‌ها جلوگیری کنید
۴. ان‌مپ را به‌روز نگه دارید
۵. نتایج اسکن را مستند کنید

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Базовое сканирование](#базовое-сканирование)
4. [Сканирование портов](#сканирование-портов)
5. [Обнаружение хостов](#обнаружение-хостов)
6. [Определение служб](#определение-служб)
7. [Определение ОС](#определение-ос)
8. [Скрипты и NSE](#скрипты-и-nse)
9. [Форматы вывода](#форматы-вывода)
10. [Лучшие практики](#лучшие-практики)

## Установка
```bash
# Установка Nmap
sudo apt update
sudo apt install nmap

# Проверка установки
nmap --version
```

## Примеры базового сканирования
```bash
# Базовое сканирование одного хоста
nmap example.com

# Сканирование определенных портов
nmap -p 80,443 example.com

# Сканирование подсети
nmap 192.168.1.0/24
```

## Лучшие практики
1. Всегда получайте надлежащее разрешение
2. Используйте подходящие временные параметры сканирования
3. Избегайте нарушения работы служб
4. Поддерживайте Nmap в актуальном состоянии
5. Документируйте результаты сканирования
