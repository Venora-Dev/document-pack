# 🚀 Laravel on Nginx Guide | راهنمای لاراول روی Nginx | Руководство по Laravel на Nginx

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Nginx Installation](#nginx-installation)
4. [PHP Installation](#php-installation)
5. [Laravel Setup](#laravel-setup)
6. [Nginx Configuration](#nginx-configuration)
7. [SSL/TLS Setup](#ssltls-setup)
8. [Performance Optimization](#performance-optimization)

## Introduction
This guide covers deploying Laravel applications on Nginx, including server setup, configuration, and optimization techniques.

## Prerequisites
- Ubuntu/Debian server
- Root or sudo access
- Domain name (for production)

## Nginx Installation
```bash
# Update system packages
sudo apt update
sudo apt upgrade

# Install Nginx
sudo apt install nginx

# Start and enable Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

## PHP Installation
```bash
# Install PHP and required extensions
sudo apt install php8.1-fpm php8.1-cli php8.1-mysql \
    php8.1-mbstring php8.1-xml php8.1-curl \
    php8.1-zip php8.1-gd php8.1-bcmath
```

## Nginx Configuration Example
```nginx
server {
    listen 80;
    server_name example.com;
    root /var/www/laravel/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

## Performance Optimization
```nginx
# Enable Gzip compression
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

# Browser caching
location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    expires 30d;
    add_header Cache-Control "public, no-transform";
}
```

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [پیش‌نیازها](#پیش‌نیازها)
3. [نصب Nginx](#نصب-nginx)
4. [نصب PHP](#نصب-php)
5. [راه‌اندازی لاراول](#راه‌اندازی-لاراول)
6. [پیکربندی Nginx](#پیکربندی-nginx)
7. [راه‌اندازی SSL/TLS](#راه‌اندازی-ssltls)
8. [بهینه‌سازی عملکرد](#بهینه‌سازی-عملکرد)

## نصب Nginx
```bash
# به‌روزرسانی بسته‌های سیستم
sudo apt update
sudo apt upgrade

# نصب Nginx
sudo apt install nginx

# شروع و فعال‌سازی Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

## نصب PHP
```bash
# نصب PHP و افزونه‌های مورد نیاز
sudo apt install php8.1-fpm php8.1-cli php8.1-mysql \
    php8.1-mbstring php8.1-xml php8.1-curl \
    php8.1-zip php8.1-gd php8.1-bcmath
```

## مثال پیکربندی Nginx
```nginx
server {
    listen 80;
    server_name example.com;
    root /var/www/laravel/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
}
```

## بهینه‌سازی عملکرد
۱. فعال‌سازی فشرده‌سازی Gzip
۲. پیکربندی کش مرورگر
۳. بهینه‌سازی PHP-FPM
۴. استفاده از SSL/TLS
۵. تنظیم محدودیت‌های بافر

# Русский

## Содержание
1. [Введение](#введение)
2. [Предварительные требования](#предварительные-требования)
3. [Установка Nginx](#установка-nginx)
4. [Установка PHP](#установка-php)
5. [Настройка Laravel](#настройка-laravel)
6. [Конфигурация Nginx](#конфигурация-nginx)
7. [Настройка SSL/TLS](#настройка-ssltls)
8. [Оптимизация производительности](#оптимизация-производительности)

## Установка Nginx
```bash
# Обновление системных пакетов
sudo apt update
sudo apt upgrade

# Установка Nginx
sudo apt install nginx

# Запуск и включение Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

## Установка PHP
```bash
# Установка PHP и необходимых расширений
sudo apt install php8.1-fpm php8.1-cli php8.1-mysql \
    php8.1-mbstring php8.1-xml php8.1-curl \
    php8.1-zip php8.1-gd php8.1-bcmath
```

## Пример конфигурации Nginx
```nginx
server {
    listen 80;
    server_name example.com;
    root /var/www/laravel/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
}
```

## Оптимизация производительности
1. Включение сжатия Gzip
2. Настройка кэширования браузера
3. Оптимизация PHP-FPM
4. Использование SSL/TLS
5. Настройка буферных ограничений
