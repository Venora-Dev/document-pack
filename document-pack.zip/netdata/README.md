# 📊 Netdata Guide | راهنمای نت‌دیتا | Руководство по Netdata

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Monitoring](#monitoring)
5. [Alerts](#alerts)
6. [API Usage](#api-usage)
7. [Plugins](#plugins)
8. [Best Practices](#best-practices)

## Introduction
Netdata is a distributed, real-time performance and health monitoring system for systems, hardware, containers, and applications.

## Installation
### One-line Installation
```bash
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

### Manual Installation
```bash
# Install dependencies
sudo apt-get install zlib1g-dev uuid-dev libuv1-dev liblz4-dev libjudy-dev libssl-dev libmnl-dev gcc make git autoconf autoconf-archive autogen automake pkg-config python3 python3-mysqldb python3-yaml

# Clone Netdata
git clone https://github.com/netdata/netdata.git --depth=100
cd netdata

# Install
./netdata-installer.sh
```

## Configuration Example
```yaml
# /etc/netdata/netdata.conf
[global]
    history = 3996
    memory mode = save
    update every = 1

[web]
    bind to = *
    allow connections from = localhost 192.168.* 10.*
```

## Monitoring Example
### Custom Python Plugin
```python
#!/usr/bin/env python3

from bases.FrameworkServices.SimpleService import SimpleService

class CustomMonitor(SimpleService):
    def __init__(self, configuration=None, name=None):
        SimpleService.__init__(self, configuration=configuration, name=name)
        self.order = ['metric1', 'metric2']
        self.definitions = {
            'metric1': {'options': [None, 'Metric 1', 'units', 'group', 'id', 'line']},
            'metric2': {'options': [None, 'Metric 2', 'units', 'group', 'id', 'line']}
        }

    def get_data(self):
        return {
            'metric1': 100,
            'metric2': 200
        }
```

## Best Practices
1. Monitor system resources
2. Configure proper retention
3. Set up alerts for critical metrics
4. Use custom dashboards
5. Regular backups of configuration

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [پیکربندی](#پیکربندی)
4. [نظارت](#نظارت)
5. [هشدارها](#هشدارها)
6. [استفاده از API](#استفاده-از-api)
7. [افزونه‌ها](#افزونه‌ها)
8. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)

## نصب
### نصب یک خطی
```bash
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

### نصب دستی
```bash
# نصب وابستگی‌ها
sudo apt-get install zlib1g-dev uuid-dev libuv1-dev liblz4-dev libjudy-dev libssl-dev libmnl-dev gcc make git autoconf autoconf-archive autogen automake pkg-config python3 python3-mysqldb python3-yaml

# کلون نت‌دیتا
git clone https://github.com/netdata/netdata.git --depth=100
cd netdata

# نصب
./netdata-installer.sh
```

## بهترین شیوه‌ها
۱. نظارت بر منابع سیستم
۲. پیکربندی نگهداری مناسب
۳. تنظیم هشدار برای معیارهای بحرانی
۴. استفاده از داشبوردهای سفارشی
۵. پشتیبان‌گیری منظم از پیکربندی

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Конфигурация](#конфигурация)
4. [Мониторинг](#мониторинг)
5. [Оповещения](#оповещения)
6. [Использование API](#использование-api)
7. [Плагины](#плагины)
8. [Лучшие практики](#лучшие-практики)

## Установка
### Установка одной строкой
```bash
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

### Ручная установка
```bash
# Установка зависимостей
sudo apt-get install zlib1g-dev uuid-dev libuv1-dev liblz4-dev libjudy-dev libssl-dev libmnl-dev gcc make git autoconf autoconf-archive autogen automake pkg-config python3 python3-mysqldb python3-yaml

# Клонирование Netdata
git clone https://github.com/netdata/netdata.git --depth=100
cd netdata

# Установка
./netdata-installer.sh
```

## Лучшие практики
1. Мониторинг системных ресурсов
2. Настройка правильного хранения данных
3. Настройка оповещений для критических метрик
4. Использование пользовательских панелей мониторинга
5. Регулярное резервное копирование конфигурации
