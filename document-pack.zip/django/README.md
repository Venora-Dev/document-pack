# 🐍🌐 Django Development Guide | راهنمای توسعه جنگو | Руководство по разработке Django

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

Welcome to this advanced guide on setting up and developing with Django, a high-level Python web framework that encourages rapid development and clean, pragmatic design.

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Installation Guide](#installation-guide)
4. [Project Structure](#project-structure)
5. [Basic Concepts](#basic-concepts)
6. [Advanced Topics](#advanced-topics)
7. [Best Practices](#best-practices)
8. [Examples](#examples)

## Introduction
Django is a powerful web framework written in Python that follows the Model-View-Template (MVT) architectural pattern.

## Prerequisites
- Python 3.8+
- pip (Python package manager)
- Virtual environment tool
- Basic understanding of Python

## Installation Guide
```bash
# Create virtual environment
python -m venv env

# Activate virtual environment
# On Windows
env\Scripts\activate
# On Unix or MacOS
source env/bin/activate

# Install Django
pip install django

# Create a new project
django-admin startproject myproject
cd myproject

# Create a new app
python manage.py startapp myapp
```

## Project Structure
```
myproject/
├── manage.py
├── myproject/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── myapp/
    ├── __init__.py
    ├── admin.py
    ├── models.py
    ├── views.py
    └── tests.py
```

## Basic Concepts
### Models Example
```python
from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    published_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### Views Example
```python
from django.shortcuts import render
from .models import Article

def article_list(request):
    articles = Article.objects.all().order_by('-published_date')
    return render(request, 'myapp/article_list.html', {'articles': articles})
```

### URLs Example
```python
from django.urls import path
from . import views

urlpatterns = [
    path('articles/', views.article_list, name='article_list'),
]
```

## Advanced Topics
- Custom User Models
- REST Framework Integration
- Celery Task Queue
- Caching Strategies
- Testing

## Best Practices
1. Use virtual environments
2. Keep settings modular
3. Follow PEP 8
4. Write tests
5. Use version control

## Examples
### Authentication System
```python
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def profile(request):
    return render(request, 'myapp/profile.html')
```

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [پیش‌نیازها](#پیش‌نیازها)
3. [راهنمای نصب](#راهنمای-نصب)
4. [ساختار پروژه](#ساختار-پروژه)
5. [مفاهیم پایه](#مفاهیم-پایه)
6. [موضوعات پیشرفته](#موضوعات-پیشرفته)
7. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)
8. [مثال‌ها](#مثال‌ها)

## مقدمه
جنگو یک فریم‌ورک قدرتمند وب است که با پایتون نوشته شده و از الگوی معماری MVT پیروی می‌کند.

## پیش‌نیازها
- پایتون نسخه ۳.۸ یا بالاتر
- pip (مدیر بسته پایتون)
- ابزار محیط مجازی
- درک اولیه پایتون

## راهنمای نصب
```bash
# ایجاد محیط مجازی
python -m venv env

# فعال‌سازی محیط مجازی
# در ویندوز
env\Scripts\activate
# در یونیکس یا مک
source env/bin/activate

# نصب جنگو
pip install django

# ایجاد پروژه جدید
django-admin startproject myproject
cd myproject

# ایجاد اپلیکیشن جدید
python manage.py startapp myapp
```

## ساختار پروژه
```
myproject/
├── manage.py
├── myproject/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── myapp/
    ├── __init__.py
    ├── admin.py
    ├── models.py
    ├── views.py
    └── tests.py
```

## مفاهیم پایه
### مثال مدل‌ها
```python
from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    published_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### مثال ویوها
```python
from django.shortcuts import render
from .models import Article

def article_list(request):
    articles = Article.objects.all().order_by('-published_date')
    return render(request, 'myapp/article_list.html', {'articles': articles})
```

## موضوعات پیشرفته
- مدل‌های کاربری سفارشی
- یکپارچه‌سازی REST Framework
- صف وظایف Celery
- استراتژی‌های کش‌کردن
- تست‌نویسی

## بهترین شیوه‌ها
۱. استفاده از محیط‌های مجازی
۲. مدولار نگه داشتن تنظیمات
۳. پیروی از PEP 8
۴. نوشتن تست
۵. استفاده از کنترل نسخه

# Русский

## Содержание
1. [Введение](#введение)
2. [Предварительные требования](#предварительные-требования)
3. [Руководство по установке](#руководство-по-установке)
4. [Структура проекта](#структура-проекта)
5. [Основные концепции](#основные-концепции)
6. [Продвинутые темы](#продвинутые-темы)
7. [Лучшие практики](#лучшие-практики)
8. [Примеры](#примеры)

## Введение
Django - это мощный веб-фреймворк, написанный на Python, который следует архитектурному паттерну MVT.

## Предварительные требования
- Python 3.8+
- pip (менеджер пакетов Python)
- Инструмент виртуального окружения
- Базовое понимание Python

## Руководство по установке
```bash
# Создание виртуального окружения
python -m venv env

# Активация виртуального окружения
# В Windows
env\Scripts\activate
# В Unix или MacOS
source env/bin/activate

# Установка Django
pip install django

# Создание нового проекта
django-admin startproject myproject
cd myproject

# Создание нового приложения
python manage.py startapp myapp
```

## Структура проекта
```
myproject/
├── manage.py
├── myproject/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── myapp/
    ├── __init__.py
    ├── admin.py
    ├── models.py
    ├── views.py
    └── tests.py
```

## Основные концепции
### Пример моделей
```python
from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    published_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### Пример представлений
```python
from django.shortcuts import render
from .models import Article

def article_list(request):
    articles = Article.objects.all().order_by('-published_date')
    return render(request, 'myapp/article_list.html', {'articles': articles})
```

## Продвинутые темы
- Пользовательские модели
- Интеграция REST Framework
- Очередь задач Celery
- Стратегии кэширования
- Тестирование

## Лучшие практики
1. Использование виртуальных окружений
2. Модульность настроек
3. Следование PEP 8
4. Написание тестов
5. Использование системы контроля версий
