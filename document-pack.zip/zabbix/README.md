# 📊 Zabbix Guide | راهنمای زبیکس | Руководство по Zabbix

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Monitoring](#monitoring)
6. [Templates](#templates)
7. [Triggers](#triggers)
8. [Alerts](#alerts)

## Introduction
Zabbix is an enterprise-class open source monitoring solution for networks and applications. It provides powerful monitoring capabilities, flexible notification methods, and extensive visualization options.

## Prerequisites
- LAMP Stack (Linux, Apache, MySQL, PHP)
- Server with minimum 2GB RAM
- Supported database (MySQL/PostgreSQL)

## Installation
```bash
# Add Zabbix repository
wget https://repo.zabbix.com/zabbix/6.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo dpkg -i zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo apt update

# Install Zabbix server, frontend, and agent
sudo apt install zabbix-server-mysql zabbix-frontend-php zabbix-apache-conf zabbix-sql-scripts zabbix-agent

# Create database
mysql -uroot -p
```

### Database Setup
```sql
create database zabbix character set utf8mb4 collate utf8mb4_bin;
create user zabbix@localhost identified by 'password';
grant all privileges on zabbix.* to zabbix@localhost;
quit;
```

### Import Schema
```bash
zcat /usr/share/doc/zabbix-sql-scripts/mysql/server.sql.gz | mysql -uzabbix -p zabbix
```

## Configuration Example
```ini
# /etc/zabbix/zabbix_server.conf
DBHost=localhost
DBName=zabbix
DBUser=zabbix
DBPassword=password
ListenPort=10051
```

## Monitoring Example
### Host Configuration
```xml
<?xml version="1.0" encoding="UTF-8"?>
<zabbix_export>
    <hosts>
        <host>
            <host>Example Server</host>
            <name>Example Server</name>
            <templates>
                <template>
                    <name>Template OS Linux by Zabbix agent</name>
                </template>
            </templates>
            <interfaces>
                <interface>
                    <ip>192.168.1.10</ip>
                    <port>10050</port>
                </interface>
            </interfaces>
            <groups>
                <group>
                    <name>Linux servers</name>
                </group>
            </groups>
        </host>
    </hosts>
</zabbix_export>
```

## Best Practices
1. Use templates for consistent monitoring
2. Implement proper user permissions
3. Regular database maintenance
4. Monitor Zabbix performance
5. Use proxies for distributed monitoring

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [پیش‌نیازها](#پیش‌نیازها)
3. [نصب](#نصب)
4. [پیکربندی](#پیکربندی)
5. [نظارت](#نظارت)
6. [قالب‌ها](#قالب‌ها)
7. [تریگرها](#تریگرها)
8. [هشدارها](#هشدارها)

## نصب
```bash
# افزودن مخزن زبیکس
wget https://repo.zabbix.com/zabbix/6.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo dpkg -i zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo apt update

# نصب سرور زبیکس، رابط کاربری و عامل
sudo apt install zabbix-server-mysql zabbix-frontend-php zabbix-apache-conf zabbix-sql-scripts zabbix-agent
```

## بهترین شیوه‌ها
۱. استفاده از قالب‌ها برای نظارت یکپارچه
۲. پیاده‌سازی مجوزهای کاربری مناسب
۳. نگهداری منظم پایگاه داده
۴. نظارت بر عملکرد زبیکس
۵. استفاده از پراکسی‌ها برای نظارت توزیع شده

# Русский

## Содержание
1. [Введение](#введение)
2. [Предварительные требования](#предварительные-требования)
3. [Установка](#установка)
4. [Конфигурация](#конфигурация)
5. [Мониторинг](#мониторинг)
6. [Шаблоны](#шаблоны)
7. [Триггеры](#триггеры)
8. [Оповещения](#оповещения)

## Установка
```bash
# Добавление репозитория Zabbix
wget https://repo.zabbix.com/zabbix/6.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo dpkg -i zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo apt update

# Установка сервера Zabbix, веб-интерфейса и агента
sudo apt install zabbix-server-mysql zabbix-frontend-php zabbix-apache-conf zabbix-sql-scripts zabbix-agent
```

## Лучшие практики
1. Использование шаблонов для согласованного мониторинга
2. Внедрение правильных разрешений пользователей
3. Регулярное обслуживание базы данных
4. Мониторинг производительности Zabbix
5. Использование прокси для распределенного мониторинга
