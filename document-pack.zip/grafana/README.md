# 📊 Grafana Guide | راهنمای گرافانا | Руководство по Grafana

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Basic Concepts](#basic-concepts)
4. [Dashboards](#dashboards)
5. [Data Sources](#data-sources)
6. [Alerts](#alerts)
7. [Best Practices](#best-practices)
8. [Examples](#examples)

## Introduction
Grafana is an open-source analytics and monitoring solution that allows you to query, visualize, and alert on metrics from various data sources.

## Installation
```bash
# Add Grafana GPG key
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -

# Add repository
echo "deb https://packages.grafana.com/oss/deb stable main" | sudo tee /etc/apt/sources.list.d/grafana.list

# Install Grafana
sudo apt-get update
sudo apt-get install grafana

# Start and enable Grafana
sudo systemctl start grafana-server
sudo systemctl enable grafana-server
```

## Basic Concepts
- **Dashboard**: Collection of panels organized in a grid
- **Panel**: Basic visualization unit (graph, table, etc.)
- **Data Source**: Backend for your data (Prometheus, InfluxDB, etc.)
- **Query**: How you retrieve data from a data source
- **Organization**: Tenant that contains dashboards and users

## Dashboards Example
```json
{
  "dashboard": {
    "id": null,
    "title": "Production Overview",
    "tags": ["production", "metrics"],
    "timezone": "browser",
    "panels": [
      {
        "title": "CPU Usage",
        "type": "graph",
        "datasource": "Prometheus",
        "targets": [
          {
            "expr": "node_cpu_seconds_total{mode='idle'}",
            "legendFormat": "{{cpu}}"
          }
        ]
      }
    ]
  }
}
```

## Data Sources Configuration
```yaml
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
```

## Alerts Configuration
```yaml
apiVersion: 1
groups:
  - name: example
    rules:
      - alert: HighCPUUsage
        expr: cpu_usage_idle < 10
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: High CPU usage detected
```

## Best Practices
1. Use consistent naming conventions
2. Organize dashboards by service/team
3. Use variables for reusable dashboards
4. Implement proper access control
5. Regular backup of dashboards

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [مفاهیم پایه](#مفاهیم-پایه)
4. [داشبوردها](#داشبوردها)
5. [منابع داده](#منابع-داده)
6. [هشدارها](#هشدارها)
7. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)
8. [مثال‌ها](#مثال‌ها)

## مقدمه
گرافانا یک راه‌حل متن‌باز برای تجزیه و تحلیل و نظارت است که به شما امکان می‌دهد داده‌ها را از منابع مختلف پرس‌وجو، مصور‌سازی و هشدار دهید.

## نصب
```bash
# افزودن کلید GPG گرافانا
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -

# افزودن مخزن
echo "deb https://packages.grafana.com/oss/deb stable main" | sudo tee /etc/apt/sources.list.d/grafana.list

# نصب گرافانا
sudo apt-get update
sudo apt-get install grafana

# شروع و فعال‌سازی گرافانا
sudo systemctl start grafana-server
sudo systemctl enable grafana-server
```

## مفاهیم پایه
- **داشبورد**: مجموعه‌ای از پنل‌ها در یک شبکه
- **پنل**: واحد پایه تجسم‌سازی (نمودار، جدول و غیره)
- **منبع داده**: بک‌اند برای داده‌های شما (Prometheus، InfluxDB و غیره)
- **پرس‌وجو**: نحوه بازیابی داده از منبع داده
- **سازمان**: واحدی که شامل داشبوردها و کاربران است

## بهترین شیوه‌ها
۱. استفاده از قراردادهای نام‌گذاری یکسان
۲. سازماندهی داشبوردها بر اساس سرویس/تیم
۳. استفاده از متغیرها برای داشبوردهای قابل استفاده مجدد
۴. پیاده‌سازی کنترل دسترسی مناسب
۵. پشتیبان‌گیری منظم از داشبوردها

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Основные концепции](#основные-концепции)
4. [Панели мониторинга](#панели-мониторинга)
5. [Источники данных](#источники-данных)
6. [Оповещения](#оповещения)
7. [Лучшие практики](#лучшие-практики)
8. [Примеры](#примеры)

## Введение
Grafana - это решение с открытым исходным кодом для аналитики и мониторинга, которое позволяет запрашивать, визуализировать метрики и настраивать оповещения из различных источников данных.

## Установка
```bash
# Добавление GPG-ключа Grafana
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -

# Добавление репозитория
echo "deb https://packages.grafana.com/oss/deb stable main" | sudo tee /etc/apt/sources.list.d/grafana.list

# Установка Grafana
sudo apt-get update
sudo apt-get install grafana

# Запуск и включение Grafana
sudo systemctl start grafana-server
sudo systemctl enable grafana-server
```

## Основные концепции
- **Панель мониторинга**: Коллекция панелей, организованных в сетку
- **Панель**: Базовая единица визуализации (график, таблица и т.д.)
- **Источник данных**: Бэкенд для ваших данных (Prometheus, InfluxDB и т.д.)
- **Запрос**: Способ получения данных из источника
- **Организация**: Единица, содержащая панели мониторинга и пользователей

## Лучшие практики
1. Использование согласованных соглашений об именовании
2. Организация панелей мониторинга по сервисам/командам
3. Использование переменных для повторного использования панелей
4. Внедрение правильного контроля доступа
5. Регулярное резервное копирование панелей мониторинга
