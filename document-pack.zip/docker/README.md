# 🐳 Docker Guide | راهنمای داکر | Руководство по Docker

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Basic Concepts](#basic-concepts)
4. [Docker Commands](#docker-commands)
5. [Dockerfile](#dockerfile)
6. [Docker Compose](#docker-compose)
7. [Best Practices](#best-practices)
8. [Examples](#examples)

## Introduction
Docker is a platform for developing, shipping, and running applications in containers. Containers allow developers to package up an application with all its dependencies and ship it as one package.

## Installation
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install docker.io

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker
```

## Basic Concepts
- **Image**: A template for creating containers
- **Container**: A running instance of an image
- **Registry**: A storage and distribution system for Docker images
- **Dockerfile**: Instructions for building a Docker image
- **Docker Compose**: Tool for defining multi-container applications

## Docker Commands
```bash
# Basic commands
docker ps                  # List running containers
docker images             # List images
docker pull ubuntu        # Pull an image
docker run nginx          # Run a container
docker stop container_id  # Stop a container
docker rm container_id    # Remove a container
```

## Dockerfile Example
```dockerfile
# Use official Python runtime as base image
FROM python:3.9-slim

# Set working directory
WORKDIR /app

# Copy requirements
COPY requirements.txt .

# Install dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Command to run application
CMD ["python", "app.py"]
```

## Docker Compose Example
```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "5000:5000"
  redis:
    image: "redis:alpine"
  db:
    image: "postgres:13"
    environment:
      - POSTGRES_DB=myapp
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
```

## Best Practices
1. Use official base images
2. Minimize layers
3. Use .dockerignore
4. Don't run as root
5. Use multi-stage builds

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [مفاهیم پایه](#مفاهیم-پایه)
4. [دستورات داکر](#دستورات-داکر)
5. [Dockerfile](#dockerfile-فارسی)
6. [Docker Compose](#docker-compose-فارسی)
7. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)
8. [مثال‌ها](#مثال‌ها)

## مقدمه
داکر پلتفرمی برای توسعه، انتقال و اجرای برنامه‌ها در کانتینرها است. کانتینرها به توسعه‌دهندگان اجازه می‌دهند تا برنامه را با تمام وابستگی‌هایش بسته‌بندی کرده و به عنوان یک پکیج منتقل کنند.

## نصب
```bash
# اوبونتو/دبیان
sudo apt-get update
sudo apt-get install docker.io

# شروع و فعال‌سازی داکر
sudo systemctl start docker
sudo systemctl enable docker
```

## مفاهیم پایه
- **ایمیج**: قالبی برای ایجاد کانتینرها
- **کانتینر**: نمونه اجرایی از یک ایمیج
- **رجیستری**: سیستم ذخیره‌سازی و توزیع ایمیج‌های داکر
- **Dockerfile**: دستورالعمل‌های ساخت ایمیج داکر
- **Docker Compose**: ابزاری برای تعریف برنامه‌های چند کانتینری

## دستورات داکر
```bash
# دستورات پایه
docker ps                  # نمایش کانتینرهای در حال اجرا
docker images             # نمایش ایمیج‌ها
docker pull ubuntu        # دریافت ایمیج
docker run nginx          # اجرای کانتینر
docker stop container_id  # توقف کانتینر
docker rm container_id    # حذف کانتینر
```

## Dockerfile مثال
```dockerfile
# استفاده از ایمیج رسمی پایتون به عنوان ایمیج پایه
FROM python:3.9-slim

# تنظیم دایرکتوری کاری
WORKDIR /app

# کپی نیازمندی‌ها
COPY requirements.txt .

# نصب وابستگی‌ها
RUN pip install --no-cache-dir -r requirements.txt

# کپی کد برنامه
COPY . .

# دستور برای اجرای برنامه
CMD ["python", "app.py"]
```

## Docker Compose مثال
```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "5000:5000"
  redis:
    image: "redis:alpine"
  db:
    image: "postgres:13"
    environment:
      - POSTGRES_DB=myapp
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
```

## بهترین شیوه‌ها
1. استفاده از ایمیج‌های رسمی
2. کاهش لایه‌ها
3. استفاده از .dockerignore
4. عدم اجرای به عنوان ریشه
5. استفاده از ساخت‌های چند مرحله‌ای

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Основные концепции](#основные-концепции)
4. [Команды Docker](#команды-docker)
5. [Dockerfile](#dockerfile-русский)
6. [Docker Compose](#docker-compose-русский)
7. [Лучшие практики](#лучшие-практики)
8. [Примеры](#примеры)

## Введение
Docker - это платформа для разработки, доставки и запуска приложений в контейнерах. Контейнеры позволяют разработчикам упаковывать приложение со всеми его зависимостями и доставлять его как единый пакет.

## Установка
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install docker.io

# Запуск и включение Docker
sudo systemctl start docker
sudo systemctl enable docker
```

## Основные концепции
- **Образ**: Шаблон для создания контейнеров
- **Контейнер**: Запущенный экземпляр образа
- **Реестр**: Система хранения и распространения образов Docker
- **Dockerfile**: Инструкции для сборки образа Docker
- **Docker Compose**: Инструмент для определения многоконтейнерных приложений

## Команды Docker
```bash
# Основные команды
docker ps                  # Список запущенных контейнеров
docker images             # Список образов
docker pull ubuntu        # Загрузка образа
docker run nginx          # Запуск контейнера
docker stop container_id  # Остановка контейнера
docker rm container_id    # Удаление контейнера
```

## Пример Dockerfile
```dockerfile
# Использование официального образа Python в качестве базового
FROM python:3.9-slim

# Установка рабочего каталога
WORKDIR /app

# Копирование зависимостей
COPY requirements.txt .

# Установка зависимостей
RUN pip install --no-cache-dir -r requirements.txt

# Копирование кода приложения
COPY . .

# Команда для запуска приложения
CMD ["python", "app.py"]
```

## Пример Docker Compose
```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "5000:5000"
  redis:
    image: "redis:alpine"
  db:
    image: "postgres:13"
    environment:
      - POSTGRES_DB=myapp
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
```

## Лучшие практики
1. Использование официальных базовых образов
2. Минимизация слоев
3. Использование .dockerignore
4. Не запускать от имени root
5. Использование многоэтапных сборок
