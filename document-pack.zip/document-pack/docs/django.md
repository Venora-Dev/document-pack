# 🐍🌐 Comprehensive Guide to Setting Up and Developing with Django

Welcome to this advanced guide on setting up and developing with Django, a high-level Python web framework that encourages rapid development and clean, pragmatic design. Let's dive deep into the world of Django! 🚀

## 📋 Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Environment Setup](#environment-setup)
4. [Creating a Django Project](#creating-a-django-project)
5. [Django Apps](#django-apps)
6. [Models and Databases](#models-and-databases)
7. [Views and URLs](#views-and-urls)
8. [Templates](#templates)
9. [Static and Media Files](#static-and-media-files)
10. [Forms and Validation](#forms-and-validation)
11. [Authentication and Authorization](#authentication-and-authorization)
12. [Middleware](#middleware)
13. [Internationalization and Localization](#internationalization-and-localization)
14. [Testing](#testing)
15. [Deployment](#deployment)
16. [Advanced Topics](#advanced-topics)
17. [Conclusion](#conclusion)
18. [Resources](#resources)

### 1️⃣ Introduction
Django is a powerful web framework written in Python that follows the Model-View-Template (MVT) architectural pattern. It emphasizes reusability and "pluggability" of components, rapid development, and the principle of Don't Repeat Yourself (DRY).

### 2️⃣ Prerequisites
Before you begin, ensure you have:
- Basic understanding of Python programming 🐍
- Familiarity with web development concepts (HTTP, HTML, CSS)
- Python 3.8 or higher installed on your machine

### 3️⃣ Environment Setup
#### Installing Python
```bash
# Download and install Python from python.org
python --version  # Verify installation
```

#### Virtual Environments
```bash
# Create virtual environment
python -m venv env

# Activate virtual environment
# Windows:
env\Scripts\activate
# macOS/Linux:
source env/bin/activate
```

#### Installing Django
```bash
pip install django
django-admin --version  # Verify installation
```

### 4️⃣ Creating a Django Project
```bash
django-admin startproject myproject
cd myproject
```

Project structure:
```
myproject/
├── manage.py
└── myproject/
    ├── __init__.py
    ├── asgi.py
    ├── settings.py
    ├── urls.py
    └── wsgi.py
```

### 5️⃣ Django Apps
```bash
python manage.py startapp myapp
```

Add to INSTALLED_APPS:
```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'myapp.apps.MyappConfig',  # Add your app here
]
```

### 6️⃣ Models and Databases
```python
from django.db import models

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```

### 7️⃣ Views and URLs
```python
# views.py
from django.shortcuts import render
from .models import Post

def post_list(request):
    posts = Post.objects.all()
    return render(request, 'blog/post_list.html', {'posts': posts})

# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list, name='post_list'),
]
```

### 8️⃣ Templates
```html
{% extends 'base.html' %}

{% block content %}
  {% for post in posts %}
    <h2>{{ post.title }}</h2>
    <p>{{ post.content }}</p>
  {% endfor %}
{% endblock %}
```

### 9️⃣ Static and Media Files
```python
# settings.py
STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'
```

### 🔟 Forms and Validation
```python
from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content']
```

### 1️⃣1️⃣ Authentication and Authorization
```python
# settings.py
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]

# Using Django's built-in auth
from django.contrib.auth.decorators import login_required

@login_required
def protected_view(request):
    return render(request, 'protected.html')
```

### 1️⃣2️⃣ Middleware
```python
# Custom middleware example
class SimpleMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Code to be executed before the view
        response = self.get_response(request)
        # Code to be executed after the view
        return response
```

### 1️⃣3️⃣ Internationalization and Localization
```python
# settings.py
LANGUAGE_CODE = 'en-us'
USE_I18N = True
USE_L10N = True
```

### 1️⃣4️⃣ Testing
```python
from django.test import TestCase
from .models import Post

class PostTests(TestCase):
    def test_post_creation(self):
        post = Post.objects.create(title='Test Post')
        self.assertEqual(post.title, 'Test Post')
```

### 1️⃣5️⃣ Deployment
Prepare your project for deployment:
- Set `DEBUG = False` in `settings.py` and configure `ALLOWED_HOSTS`.
- Collect static files:
  ```bash
  python manage.py collectstatic
  ```
- Use a production-grade WSGI server like Gunicorn:
  ```bash
  pip install gunicorn
  gunicorn myproject.wsgi:application
  ```

### 1️⃣6️⃣ Advanced Topics
Explore advanced Django features like custom management commands, signals, and caching strategies to optimize your application.

### 1️⃣7️⃣ Conclusion
You've mastered setting up and developing with Django! Keep exploring the vast ecosystem Django offers and build amazing web applications. 🎉

### 1️⃣8️⃣ Resources 📚
- [Official Documentation](https://docs.djangoproject.com)
- [Django REST Framework](https://www.django-rest-framework.org/)
- [Django Packages](https://djangopackages.org/)

## 🌍 Language Versions
- [English](../en/django.md) - English documentation
- [فارسی](../fa/django.md) - مستندات فارسی
- [Русский](../ru/django.md) - Документация на русском

Happy coding with Django! 🚀🐍
