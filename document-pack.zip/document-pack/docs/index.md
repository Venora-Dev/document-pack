# Technical Documentation Hub

Welcome to our comprehensive technical documentation hub. This collection of guides covers various technologies and tools used in modern development and system administration.

## Available Documentation

### Web Development
- [Django Framework Guide](django.md) - Python web framework documentation
- [Laravel API Development](laravel_api.md) - RESTful API development with Laravel
- [Laravel on Nginx](laravel_on_nginx.md) - Deploying Laravel applications with Nginx
- [Nginx Configuration](nginx.md) - Web server setup and optimization

### Containerization & Deployment
- [Docker Guide](docker.md) - Container management and deployment
- [Nginx Server Configuration](nginx.md) - Web server setup and configuration

### Monitoring & Analytics
- [Grafana](grafana.md) - Data visualization and monitoring
- [LibreNMS](librenms.md) - Network monitoring system
- [Zabbix](zabbix.md) - Enterprise-class monitoring solution
- [Netdata](netdata.md) - Real-time performance monitoring

### Security & Network Tools
- [Nmap Guide](nmap.md) - Network discovery and security scanning

### Automation
- [Telegram Bot Development](telegram_bot.md) - Building automated bots for Telegram

## Contributing
If you'd like to contribute to this documentation, please check our [contribution guidelines](../README.md).

## License
This documentation is licensed under the terms specified in our [LICENSE](../LICENSE) file.
