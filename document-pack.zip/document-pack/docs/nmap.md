# 🔍 Comprehensive Guide to Nmap

Welcome to this advanced guide on Nmap - a powerful network scanning tool! 🚀

## 📋 Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Basic Scanning](#basic-scanning)
5. [Scan Types](#scan-types)
6. [Service Detection](#service-detection)
7. [NSE Scripts](#nse-scripts)
8. [Firewall Evasion](#firewall-evasion)
9. [Optimization](#optimization)
10. [Output Formats](#output-formats)
11. [Security](#security)
12. [Integration](#integration)
13. [Automation](#automation)
14. [Troubleshooting](#troubleshooting)
15. [Best Practices](#best-practices)
16. [Advanced Topics](#advanced-topics)
17. [Conclusion](#conclusion)
18. [Resources](#resources)

### 1️⃣ Introduction
Nmap is a powerful network scanning and security auditing tool.

### 2️⃣ Prerequisites
- Linux/Windows/macOS
- Root/Administrator privileges
- Basic networking knowledge

### 3️⃣ Installation
```bash
# Install on Ubuntu
sudo apt update
sudo apt install nmap

# Check version
nmap --version
```

### 1️⃣7️⃣ Conclusion
You now have mastery over a powerful network scanning tool! 🎉

### 1️⃣8️⃣ Resources 📚
- [Official Documentation](https://nmap.org/docs.html)
- [Nmap Book](https://nmap.org/book/)
- [NSE Scripts](https://nmap.org/nsedoc/)

## Related Documentation
- [LibreNMS](librenms.md)
- [Zabbix](zabbix.md)
- [NetData](netdata.md)

## 🌍 Language Versions
- [English](../en/nmap.md) - English documentation
- [فارسی](../fa/nmap.md) - Persian documentation
- [Русский](../ru/nmap.md) - Russian documentation

Happy scanning! 🔍🚀
