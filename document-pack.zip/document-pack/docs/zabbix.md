# 📊 Comprehensive Guide to Zabbix

Welcome to this advanced guide on Zabbix - a powerful enterprise monitoring solution! 🚀

## 📋 Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Initial Setup](#initial-setup)
5. [Adding Hosts](#adding-hosts)
6. [Templates](#templates)
7. [Monitoring](#monitoring)
8. [Triggers](#triggers)
9. [Alerts](#alerts)
10. [Graphs](#graphs)
11. [Proxies](#proxies)
12. [API](#api)
13. [Backup](#backup)
14. [Troubleshooting](#troubleshooting)
15. [Optimization](#optimization)
16. [Advanced Topics](#advanced-topics)
17. [Conclusion](#conclusion)
18. [Resources](#resources)

### 1️⃣ Introduction
Zabbix is an enterprise-class open source distributed monitoring solution.

### 2️⃣ Prerequisites
- Linux server
- MySQL/PostgreSQL
- PHP 7.4+
- Apache/Nginx

### 3️⃣ Installation
```bash
# Install Zabbix repository
wget https://repo.zabbix.com/zabbix/6.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo dpkg -i zabbix-release_6.0-1+ubuntu20.04_all.deb
sudo apt update

# Install server and frontend
sudo apt install zabbix-server-mysql zabbix-frontend-php
```

### 1️⃣7️⃣ Conclusion
You now have a professional enterprise monitoring system! 🎉

### 1️⃣8️⃣ Resources 📚
- [Official Documentation](https://www.zabbix.com/documentation/)
- [Zabbix Forum](https://www.zabbix.com/forum/)
- [Zabbix Training](https://www.zabbix.com/training)

## Related Documentation
- [Grafana](grafana.md)
- [LibreNMS](librenms.md)
- [NetData](netdata.md)

## 🌍 Language Versions
- [English](../en/zabbix.md) - English documentation
- [فارسی](../fa/zabbix.md) - Persian documentation
- [Русский](../ru/zabbix.md) - Russian documentation

Happy monitoring! 📊🔍
