---
name: Bug report
about: Create a report to help us improve the documentation
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the documentation issue is.

**Expected content**
A clear and concise description of what you expected to find in the documentation.

**Additional context**
Add any other context about the problem here.
