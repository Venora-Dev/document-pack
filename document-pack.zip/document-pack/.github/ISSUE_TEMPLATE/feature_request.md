---
name: Feature request
about: Suggest new documentation content
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Is your feature request related to missing documentation? Please describe.**
A clear and concise description of what documentation you'd like to see added.

**Describe the solution you'd like**
A clear and concise description of what content you want to be added.

**Additional context**
Add any other context about the documentation request here.
