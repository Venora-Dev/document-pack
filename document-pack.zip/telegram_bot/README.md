# 🤖 Telegram Bot Guide | راهنمای ربات تلگرام | Руководство по Telegram боту

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Bot Creation](#bot-creation)
4. [Development Setup](#development-setup)
5. [Basic Bot Functions](#basic-bot-functions)
6. [Advanced Features](#advanced-features)
7. [Deployment](#deployment)
8. [Best Practices](#best-practices)

## Introduction
This guide covers creating and deploying Telegram bots using Python's python-telegram-bot library, including handling messages, commands, and implementing advanced features.

## Prerequisites
- Python 3.7+
- python-telegram-bot library
- Telegram account
- Bot token from @BotFather

## Bot Creation
1. Start a chat with @BotFather on Telegram
2. Use `/newbot` command
3. Follow instructions to set name and username
4. Save the API token provided

## Basic Bot Example
```python
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

def start(update, context):
    update.message.reply_text('Hello! I am your bot.')

def echo(update, context):
    update.message.reply_text(update.message.text)

def main():
    updater = Updater("YOUR_TOKEN_HERE", use_context=True)
    dp = updater.dispatcher

    # Command handlers
    dp.add_handler(CommandHandler("start", start))

    # Message handlers
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, echo))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
```

## Advanced Features Example
```python
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def button_menu(update, context):
    keyboard = [
        [InlineKeyboardButton("Option 1", callback_data='1'),
         InlineKeyboardButton("Option 2", callback_data='2')],
        [InlineKeyboardButton("Option 3", callback_data='3')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Please choose:', reply_markup=reply_markup)
```

## Best Practices
1. Implement error handling
2. Use conversation handlers for complex flows
3. Implement rate limiting
4. Secure sensitive data
5. Log important events

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [پیش‌نیازها](#پیش‌نیازها)
3. [ساخت ربات](#ساخت-ربات)
4. [راه‌اندازی محیط توسعه](#راه‌اندازی-محیط-توسعه)
5. [توابع پایه ربات](#توابع-پایه-ربات)
6. [ویژگی‌های پیشرفته](#ویژگی‌های-پیشرفته)
7. [استقرار](#استقرار)
8. [بهترین شیوه‌ها](#بهترین-شیوه‌ها)

## نصب و راه‌اندازی
```python
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

def start(update, context):
    update.message.reply_text('سلام! من ربات شما هستم.')

def echo(update, context):
    update.message.reply_text(update.message.text)

def main():
    updater = Updater("توکن_شما", use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, echo))

    updater.start_polling()
    updater.idle()
```

## بهترین شیوه‌ها
۱. پیاده‌سازی مدیریت خطا
۲. استفاده از مدیریت‌کننده مکالمه برای جریان‌های پیچیده
۳. پیاده‌سازی محدودیت نرخ
۴. ایمن‌سازی داده‌های حساس
۵. ثبت رویدادهای مهم

# Русский

## Содержание
1. [Введение](#введение)
2. [Предварительные требования](#предварительные-требования)
3. [Создание бота](#создание-бота)
4. [Настройка разработки](#настройка-разработки)
5. [Основные функции бота](#основные-функции-бота)
6. [Расширенные возможности](#расширенные-возможности)
7. [Развертывание](#развертывание)
8. [Лучшие практики](#лучшие-практики)

## Установка и настройка
```python
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

def start(update, context):
    update.message.reply_text('Привет! Я ваш бот.')

def echo(update, context):
    update.message.reply_text(update.message.text)

def main():
    updater = Updater("ВАШ_ТОКЕН", use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, echo))

    updater.start_polling()
    updater.idle()
```

## Лучшие практики
1. Реализация обработки ошибок
2. Использование обработчиков разговоров для сложных потоков
3. Внедрение ограничения частоты запросов
4. Защита конфиденциальных данных
5. Логирование важных событий
