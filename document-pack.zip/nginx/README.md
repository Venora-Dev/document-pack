# 🌐 Nginx Guide | راهنمای انجینکس | Руководство по Nginx

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Basic Configuration](#basic-configuration)
4. [Virtual Hosts](#virtual-hosts)
5. [SSL/TLS Setup](#ssltls-setup)
6. [Load Balancing](#load-balancing)
7. [Reverse Proxy](#reverse-proxy)
8. [Security](#security)
9. [Performance Tuning](#performance-tuning)
10. [Monitoring](#monitoring)

## Installation
```bash
# Install Nginx
sudo apt update
sudo apt install nginx

# Verify installation
nginx -v
```

## Basic Configuration Example
```nginx
# /etc/nginx/nginx.conf
user www-data;
worker_processes auto;
pid /run/nginx.pid;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    gzip on;
    gzip_disable "msie6";
}
```

## Virtual Host Example
```nginx
# /etc/nginx/sites-available/example.com
server {
    listen 80;
    server_name example.com www.example.com;
    root /var/www/example.com;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
    }
}
```

## Load Balancing Example
```nginx
upstream backend {
    server backend1.example.com:8080;
    server backend2.example.com:8080;
    server backend3.example.com:8080;
}

server {
    listen 80;
    server_name example.com;

    location / {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Best Practices
1. Use SSL/TLS certificates
2. Enable HTTP/2
3. Configure proper caching
4. Implement rate limiting
5. Regular security updates

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [نصب](#نصب)
3. [پیکربندی پایه](#پیکربندی-پایه)
4. [میزبان‌های مجازی](#میزبان‌های-مجازی)
5. [راه‌اندازی SSL/TLS](#راه‌اندازی-ssltls)
6. [متعادل‌سازی بار](#متعادل‌سازی-بار)
7. [پراکسی معکوس](#پراکسی-معکوس)
8. [امنیت](#امنیت)
9. [بهینه‌سازی عملکرد](#بهینه‌سازی-عملکرد)
10. [نظارت](#نظارت)

## نصب
```bash
# نصب انجینکس
sudo apt update
sudo apt install nginx

# تأیید نصب
nginx -v
```

## مثال پیکربندی پایه
```nginx
# /etc/nginx/nginx.conf
user www-data;
worker_processes auto;
pid /run/nginx.pid;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
}
```

## بهترین شیوه‌ها
۱. استفاده از گواهینامه‌های SSL/TLS
۲. فعال‌سازی HTTP/2
۳. پیکربندی کش مناسب
۴. پیاده‌سازی محدودیت نرخ
۵. به‌روزرسانی‌های منظم امنیتی

# Русский

## Содержание
1. [Введение](#введение)
2. [Установка](#установка)
3. [Базовая конфигурация](#базовая-конфигурация)
4. [Виртуальные хосты](#виртуальные-хосты)
5. [Настройка SSL/TLS](#настройка-ssltls)
6. [Балансировка нагрузки](#балансировка-нагрузки)
7. [Обратный прокси](#обратный-прокси)
8. [Безопасность](#безопасность)
9. [Оптимизация производительности](#оптимизация-производительности)
10. [Мониторинг](#мониторинг)

## Установка
```bash
# Установка Nginx
sudo apt update
sudo apt install nginx

# Проверка установки
nginx -v
```

## Пример базовой конфигурации
```nginx
# /etc/nginx/nginx.conf
user www-data;
worker_processes auto;
pid /run/nginx.pid;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
}
```

## Лучшие практики
1. Использование SSL/TLS сертификатов
2. Включение HTTP/2
3. Настройка правильного кэширования
4. Внедрение ограничения скорости
5. Регулярные обновления безопасности
