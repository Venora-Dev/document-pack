# 📊 LibreNMS Guide | راهنمای LibreNMS | Руководство по LibreNMS

[English](#english) | [فارسی](#persian) | [Русский](#russian)

# English

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Adding Devices](#adding-devices)
6. [Monitoring](#monitoring)
7. [Alerting](#alerting)
8. [API Usage](#api-usage)

## Introduction
LibreNMS is a fully featured network monitoring system that provides a wealth of features and device support. It handles various protocols and platforms, offering detailed insights into network performance and health.

## Prerequisites
- LAMP Stack (Linux, Apache, MySQL, PHP)
- PHP 7.4 or newer
- MySQL/MariaDB
- Python 3
- SNMP tools

## Installation
```bash
# Install required packages
sudo apt install acl curl composer fping git graphviz imagemagick \
    mariadb-client mariadb-server mtr-tiny nginx-full nmap php-cli \
    php-curl php-fpm php-gd php-json php-mbstring php-mysql php-snmp \
    php-xml php-zip python3-mysqldb python3-dotenv python3-pip \
    python3-pymysql python3-redis redis-server rrdtool snmp \
    snmpd whois unzip

# Clone LibreNMS
sudo git clone https://github.com/librenms/librenms.git /opt/librenms

# Set permissions
sudo chown -R librenms:librenms /opt/librenms
sudo chmod 771 /opt/librenms
sudo setfacl -d -m g::rwx /opt/librenms/rrd /opt/librenms/logs
```

## Configuration Example
### Database Setup
```sql
CREATE DATABASE librenms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'librenms'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON librenms.* TO 'librenms'@'localhost';
FLUSH PRIVILEGES;
```

### Nginx Configuration
```nginx
server {
    listen      80;
    server_name librenms.example.com;
    root        /opt/librenms/html;
    index       index.php;

    charset utf-8;
    gzip on;
    gzip_types text/css application/javascript text/javascript application/x-javascript image/svg+xml text/plain text/xsd text/xsl text/xml image/x-icon;
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    location /api/v0 {
        try_files $uri $uri/ /api_v0.php?$query_string;
    }
    location ~ \.php {
        include fastcgi.conf;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
    }
}
```

## Best Practices
1. Regular backups of configuration and data
2. Implement proper access control
3. Monitor system resources
4. Keep system updated
5. Use HTTPS for security

# فارسی

## فهرست مطالب
1. [مقدمه](#مقدمه)
2. [پیش‌نیازها](#پیش‌نیازها)
3. [نصب](#نصب)
4. [پیکربندی](#پیکربندی)
5. [افزودن دستگاه‌ها](#افزودن-دستگاه‌ها)
6. [نظارت](#نظارت)
7. [هشدارها](#هشدارها)
8. [استفاده از API](#استفاده-از-api)

## نصب
```bash
# نصب بسته‌های مورد نیاز
sudo apt install acl curl composer fping git graphviz imagemagick \
    mariadb-client mariadb-server mtr-tiny nginx-full nmap php-cli \
    php-curl php-fpm php-gd php-json php-mbstring php-mysql php-snmp \
    php-xml php-zip python3-mysqldb python3-dotenv python3-pip \
    python3-pymysql python3-redis redis-server rrdtool snmp \
    snmpd whois unzip

# کلون کردن LibreNMS
sudo git clone https://github.com/librenms/librenms.git /opt/librenms

# تنظیم مجوزها
sudo chown -R librenms:librenms /opt/librenms
sudo chmod 771 /opt/librenms
```

## بهترین شیوه‌ها
۱. پشتیبان‌گیری منظم از پیکربندی و داده‌ها
۲. پیاده‌سازی کنترل دسترسی مناسب
۳. نظارت بر منابع سیستم
۴. به‌روز نگه داشتن سیستم
۵. استفاده از HTTPS برای امنیت

# Русский

## Содержание
1. [Введение](#введение)
2. [Предварительные требования](#предварительные-требования)
3. [Установка](#установка)
4. [Конфигурация](#конфигурация)
5. [Добавление устройств](#добавление-устройств)
6. [Мониторинг](#мониторинг)
7. [Оповещения](#оповещения)
8. [Использование API](#использование-api)

## Установка
```bash
# Установка необходимых пакетов
sudo apt install acl curl composer fping git graphviz imagemagick \
    mariadb-client mariadb-server mtr-tiny nginx-full nmap php-cli \
    php-curl php-fpm php-gd php-json php-mbstring php-mysql php-snmp \
    php-xml php-zip python3-mysqldb python3-dotenv python3-pip \
    python3-pymysql python3-redis redis-server rrdtool snmp \
    snmpd whois unzip

# Клонирование LibreNMS
sudo git clone https://github.com/librenms/librenms.git /opt/librenms

# Настройка прав доступа
sudo chown -R librenms:librenms /opt/librenms
sudo chmod 771 /opt/librenms
```

## Лучшие практики
1. Регулярное резервное копирование конфигурации и данных
2. Внедрение правильного контроля доступа
3. Мониторинг системных ресурсов
4. Поддержание системы в актуальном состоянии
5. Использование HTTPS для безопасности
